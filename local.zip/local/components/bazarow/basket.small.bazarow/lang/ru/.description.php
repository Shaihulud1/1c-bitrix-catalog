<?
$MESS ['SBBS_DEFAULT_TEMPLATE_NAME'] = "Малая корзина";
$MESS ['SBBS_DEFAULT_TEMPLATE_DESCRIPTION'] = "Малая корзина";
$MESS ['SBBS_NAME'] = "Корзина";
?>