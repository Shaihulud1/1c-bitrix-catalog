<?
$MESS['SALE_MODULE_NOT_INSTALL']="Модуль Интернет-магазин не установлен.";
?>