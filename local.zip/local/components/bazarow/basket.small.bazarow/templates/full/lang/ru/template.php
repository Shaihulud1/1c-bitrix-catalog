<?
$MESS['TSBS_READY'] = "Позиции в Вашей корзине:";
$MESS['TSBS_PRICE'] = "Цена:";
$MESS['TSBS_QUANTITY'] = "Количество:";
$MESS['TSBS_2BASKET'] = "Изменить количество";
$MESS['TSBS_2ORDER'] = "Оформить заказ";
$MESS['TSBS_DELAY'] = "Отложенные позиции:";
$MESS['TSBS_UNAVAIL'] = "Недоступны для покупки:";
$MESS['TSBS_SUBSCRIBE'] = "Подписка:";
?>