<?
$MESS["round_nav_back"] = "Back";
$MESS["round_nav_forward"] = "Next";
$MESS["round_nav_pages"] = "Pages";
$MESS["round_nav_all"] = "All";
?>