<?
$MESS ['bp_wizard_name'] = "Бизнес-процесс";
$MESS ['bp_wizard_title'] = "Раздел с бизнес-процессом (ЧПУ)";
$MESS ['bp_wizard_settings'] = "Настройки бизнес-процесса";
$MESS ['bp_wizard_lib_name'] = "Название бизнес-процесса:";
$MESS ['bp_wizard_lib_name_val'] = "Процесс";
$MESS ['bp_wizard_iblock_type'] = "Тип информационного блока:";
$MESS ['bp_wizard_iblock'] = "Информационный блок для документов:";
$MESS ['bp_wizard_iblock_new'] = "Создать новый тип информационного блока с кодом";
$MESS ['bp_wizard_iblock_select'] = "Выбрать существующий тип информационного блока:";
?>