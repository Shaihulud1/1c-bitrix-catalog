<?
$MESS ['bp_wizard_name'] = "Geschдftsprozess";
$MESS ['bp_wizard_lib_name'] = "Geschдftsprozessname:";
$MESS ['bp_wizard_settings'] = "Geschдftsprozessparameter";
$MESS ['bp_wizard_iblock_new'] = "Informationsblocktyp mit der ID erstellen";
$MESS ['bp_wizard_iblock'] = "Dokumentinformationsblock:";
$MESS ['bp_wizard_iblock_type'] = "Informationsblocktyp:";
$MESS ['bp_wizard_lib_name_val'] = "Prozess";
$MESS ['bp_wizard_iblock_select'] = "Wдhlen Sie einen bestehenden Informationsblocktyp:";
$MESS ['bp_wizard_title'] = "Geschдftsprozessbereich";
?>