<?
$MESS["DEF_TEMPLATE_NF"]="Template is not found. Please set template for this site.";
$MESS["DEF_TEMPLATE_NF_SET"]="Set template";
?>