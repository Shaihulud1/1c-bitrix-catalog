<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();?>
<?
$SNIPPETS = Array();
$SNIPPETS['snippet0001.snp'] = Array("title"=>'Таблица', "description"=>'');
?>