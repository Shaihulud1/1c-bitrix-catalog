<?
// fix
$MESS['USE_COMPARE'] = 'Использовать сравнение';
// ajaxpages
$MESS['AJAXPAGESID'] = 'Идентификатор ajax загрузки';
$MESS['IS_AJAXPAGES'] = 'Это ajax загрузка';
// section, element
$MESS['PROP_MORE_PHOTO'] = 'Свойство с доп. изображениями товаров';
$MESS['PROP_ARTICLE'] = 'Свойство с артикулом товара';
$MESS['PROP_ACCESSORIES'] = 'Свойство с привязкой аксессуаров';
$MESS['USE_FAVORITE'] = 'Использовать избранное';
$MESS['USE_SHARE'] = 'Использовать расшаривание материалов';
$MESS['SHOW_ERROR_EMPTY_ITEMS'] = 'Показывать ошибку, если товаров не найдено';
$MESS['PROPS_ATTRIBUTES'] = 'Характеристики товара';
$MESS['PROPS_ATTRIBUTES_COLOR'] = 'Характеристики являющиеся цветом';
$MESS['OFF_MEASURE_RATION'] = 'Выключить отображение ед. изм.';
// store
$MESS['STORES_TEMPLATE'] = 'Шаблон складов';
$MESS['USE_STORE'] = 'Показывать блок "Количество товара на складе"';
$MESS['STORE_PATH'] = 'Шаблон пути к каталогу STORE (относительно корня)';
$MESS['USE_MIN_AMOUNT'] = 'Подменять числа на выражения';
$MESS['MIN_AMOUNT'] = 'Значение, ниже которого выводится "мало"';
$MESS['STORES'] = 'Склады';
$MESS['MAIN_TITLE'] = 'Заголовок блока';
// offers
$MESS['PROP_SKU_MORE_PHOTO'] = 'Свойство с доп. изображениями торговых предложений';
$MESS['PROP_SKU_ARTICLE'] = 'Свойство с артикулом торговых предложений';