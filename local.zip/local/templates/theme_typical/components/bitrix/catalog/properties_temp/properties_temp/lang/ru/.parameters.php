<?
$MESS ['TP_BC_PRODUCT_QUANTITY_VARIABLE'] = "Название переменной, в которой передается количество товара";
$MESS ['TP_BC_PRODUCT_PROPS_VARIABLE'] = "Название переменной, в которой передаются характеристики товара";
$MESS ['TP_BC_USE_PRODUCT_QUANTITY'] = "Разрешить указание количества товара";
$MESS ['TP_BC_PRODUCT_PROPERTIES'] = "Характеристики товара";
?>