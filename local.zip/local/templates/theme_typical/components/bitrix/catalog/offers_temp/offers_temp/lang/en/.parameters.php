<?
$MESS ['TP_BC_OFFERS_FIELDS'] = "Linked element fields for detail page";
$MESS ['TP_BC_OFFERS_PROPERTIES'] = "Linked element properties for detail page";
?>