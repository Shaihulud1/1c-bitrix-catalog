<?
$MESS ['TP_BC_OFFERS_FIELDS'] = "Поля элементов предложений для показа";
$MESS ['TP_BC_OFFERS_PROPERTIES'] = "Свойства элементов предложений для показа";
?>