<?
$arTemplate = array (
  'NAME' => 'Заготовка от camouf.ru',
  'DESCRIPTION' => 'Заготовка от camouf.ru',
  'SORT' => '',
  'TYPE' => '',
);
?>